
<div align="center">
<img src="https://user-images.githubusercontent.com/87141327/127050619-19853ac0-672b-4ce2-b024-2f3da9c12e6f.jpg" width=100% alt="particulasjs" border="0">
</div>
<br/>

# KidvsKat-ParallaxScrolling

« Aprende a hacer el efecto Parallax con html, css y javascript puro, este vídeo te ayudara a desarrollar tu página web con un diseño dinámico, fácil de hacer y que no se quede atrás a nivel de diseño »
<br/>

## **Video del Proyecto** 
[2021🚀 Sitio web Responsivo con Efecto Parallax Scrolling | Utilizando Html CSS & Vanilla Javascript](https://youtu.be/f6NhnxH75TQ "Youtube")
<br/>

## Vista General
![ParallaxScrolling_v0](https://user-images.githubusercontent.com/87141327/126387961-6bc0a54a-0852-4b68-a0d1-c985da56e87f.gif)

## Estructura del Proyecto
![Imagen_20072021_143943](https://user-images.githubusercontent.com/87141327/126388550-26a7470f-4767-40f3-b1c5-8be5532f1d94.png)
<br/>

## Ayuda adicional
Para obtener más ayuda sobre el efecto parallax.js visite https://matthew.wagerfield.com/parallax/
<br/>

## Redes Sociales
`<YouTube>` : <https://www.youtube.com/channel/UCFPYlFz5afh_o7tVW--htKw>
<br/>
`<Facebook>` : <https://www.facebook.com/kidvskat.code>
