# Parallax Animation in React

This project is created as part of below YouTube video.

<p align="center"> 
    <a href="https://youtu.be/jeSPvDI-IJw" target="_blank">
    <img src="http://img.youtube.com/vi/jeSPvDI-IJw/0.jpg"></img>
  </a>
</p>
